<?php

namespace App\Http\Controllers\Management\Quiz;

use App\Http\Controllers\Controller;
use App\Models\Management\Quiz\AssignQuiz;
use App\Models\Management\ManageSetting\AddCommission\AddCommission;
use App\Models\Management\ManageSetting\commission\commission;
use App\Models\Management\ManageSetting\RoleAssign\RolesAssign;
use App\Models\Management\ManageSetting\workflow\workflow;
use App\Models\Management\Quiz\Quiz;
use Illuminate\Http\Request;
use Symfony\Component\Console\Question\Question;

class AssignQuizController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         $data['levels']= commission::get()->all();
        $data['roles']= workflow::get()->all();
        $data['quiz']= Quiz::get()->all();
        return view('management.quiz.assign_quiz.index',compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = [
            'level_id'=>$request->level_id,
            'role_id'=>$request->role_id,
            'users_id'=>$request->users_id,
            'quiz_type'=>$request->quiz_type,
            'quizzes'=>$request->quizzes,
        ];
        AssignQuiz::create($data);
        return redirect('assignquiz');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\CRUD  $cRUD
     * @return \Illuminate\Http\Response
     */
    public function show(CRUD $cRUD)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\CRUD  $cRUD
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return view('management.quiz.edit');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\CRUD  $cRUD
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {

    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\CRUD  $cRUD
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

    }

    public function GetRole ($id){
        $role = RolesAssign::where('level_id',$id)->with('role')->get()->all();
        return response()->json($role);
    }

    public function GetUsers( Request $request , $id){
            $users = RolesAssign::where('role_id',$request->rid)->where('level_id',$request->lid)->with('user')->get()->all();
        return response()->json($users);
    }
    public function GetQuiz(Request $request){
        $quiz = Quiz::where('erp_quiz_type',$request->quiz_type)->get()->all();
        return response()->json($quiz);
    }
}
