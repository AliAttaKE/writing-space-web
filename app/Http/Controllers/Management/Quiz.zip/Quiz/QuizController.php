<?php

namespace App\Http\Controllers\Management\Quiz;
use App\Http\Controllers\Controller;
use App\Models\Management\Quiz\Quiz;
use Illuminate\Http\Request;

class QuizController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

//dd('hi');
        $quiz = Quiz::get()->all();

        return view('management.quiz.quizs.index', compact('quiz'));

    }

//    public function (){
//
//
//    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $this->validate($request,[
            "status"=>"required",
            "name"=>"required",
            "quiz_format"=>"required",
            "quiz_type"=>"required",
            "timer"=>"required",
        ]);

        $data= [
            'erp_user_id'=>auth()->user()->id,
            'erp_quiz_name'=>$request->name,
            'erp_quiz_type'=>$request->quiz_type,
            'erp_quiz_formats'=>$request->quiz_format,
            'erp_quiz_result'=>$request->quiz_result,
            'erp_quiz_passing'=>$request->quiz_passing,
            'erp_quiz_timer'=>$request->timer,
            'erp_quiz_status'=>$request->status,

        ];

        $convert = Quiz::create($data);


        return redirect('quiz')->with('success','Data inserted successfully');


    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Quiz  $quiz
     * @return \Illuminate\Http\Response
     */
    public function show(Quiz $quiz)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Quiz  $quiz
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return view('management/quiz/quizs/edit');

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Quiz  $quiz
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        $data=Quiz::where('id',$id)->get()->first();
        $this->validate($request,[
            "status"=>"required",
            "name"=>"required",
            "quiz_format"=>"required",
            "quiz_type"=>"required",
            "timer"=>"required",
            ]);
        $data->update([
            'erp_quiz_name'=>$request->name,
            'erp_quiz_type'=>$request->quiz_type,
            'erp_quiz_formats'=>$request->quiz_format,
            'erp_quiz_timer'=>$request->timer,
            'erp_quiz_result'=>$request->quiz_result,
            'erp_quiz_passing'=>$request->quiz_passing,
            'erp_quiz_status'=>$request->status,
        ]);
        return redirect('quiz')->with('success','Data updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\  $quiz
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        Quiz::find($id)->delete();
        return redirect('quiz')->with('success','Data deleted successfully');

    }
}
